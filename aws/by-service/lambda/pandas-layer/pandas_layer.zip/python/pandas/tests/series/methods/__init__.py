"""
Test files dedicated to individual (stand-alone) Series methods

Ideally these files/tests should correspond 1-to-1 with tests.frame.methods

These may also present opportunities for sharing/de-duplicating test code.
"""
