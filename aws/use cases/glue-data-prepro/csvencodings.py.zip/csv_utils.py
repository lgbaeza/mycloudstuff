import boto3
import chardet 
s3 = boto3.resource('s3')

# gets s3 object content
def getS3ObjectData(INPUT_BUCKET_NAME, INPUT_FILE_PATH):
    input_object = s3.Object(INPUT_BUCKET_NAME, INPUT_FILE_PATH)
    print("Object found: {}".format(INPUT_FILE_PATH))
    return input_object.get()['Body'].read()

# detects encoding for file
def detectEncoding(rawdata): 
    result = chardet.detect(rawdata) 
    charenc = result['encoding']
    print("encoding {}".format(charenc))
    return charenc

# transforms source encoding to UTF-8
def transformCsvEncoding(s3obj, INPUT_FILE_ENCODING, OUTPUT_BUCKET_NAME, OUTPUT_FILE_PATH):
    body = s3obj.decode(INPUT_FILE_ENCODING)
    output_object = s3.Object(OUTPUT_BUCKET_NAME, OUTPUT_FILE_PATH)
    output_object.put(Body = body)
    print("file transformed to UTF8 {}".format(OUTPUT_FILE_PATH))