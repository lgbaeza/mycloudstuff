# imports helper functions
from csv_utils import detectEncoding, transformCsvEncoding, getS3ObjectData

# supported encodings
encodings = ["ISO-8859-1", "utf-8"]

# output bucket name
OUTPUT_BUCKET_NAME=''
OUTPUT_PATH = ""

def lambda_handler(event, context):
    # gets parameters from step functions
    INPUT_BUCKET_NAME = event['detail']['bucket']['name']  
    INPUT_FILE_PATH = event['detail']['object']['key'] 
    OUTPUT_FILE_PATH = OUTPUT_PATH + INPUT_FILE_PATH[INPUT_FILE_PATH.rindex("/")+1:]
    
    # gets s3 object content
    s3obj = getS3ObjectData(INPUT_BUCKET_NAME, INPUT_FILE_PATH)
    
    # detects encoding
    encoding = detectEncoding(s3obj)
    
    # transforms source encoding to UTF-8 if encoding is supported
    if(encoding in encodings):
        transformCsvEncoding(    \
            s3obj,               \
            encoding,            \
            OUTPUT_BUCKET_NAME,  \
            OUTPUT_FILE_PATH     \
        )
    else:
        # raise exception if encoding not supported
        raise Exception('Encoding not supported')